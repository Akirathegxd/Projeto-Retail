package services;

import sellout.PedidoVenda;
import sellout.ProdutoVenda;

import java.time.LocalDateTime;

public class VendaService {
    private LocalDateTime data;
    private int quantidade;
    private ProdutoVenda produtoVenda;
    private PedidoVenda pedidoVenda;

    public VendaService() {

    }

    public ProdutoVenda getProdutoVenda() {
        return new ProdutoVenda();
    }

    public PedidoVenda getPedidoVenda() {
        return new PedidoVenda();
    }
}
