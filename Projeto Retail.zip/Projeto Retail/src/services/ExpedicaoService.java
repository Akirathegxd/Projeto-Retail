package services;

import expedition.Fornecedor;
import expedition.PedidoExpedicao;
import expedition.ProdutoExpedicao;

public class ExpedicaoService {
    private Fornecedor fornecedor;
    private ProdutoExpedicao produtoExpedicao;
    private PedidoExpedicao pedidoExpedicao;

    public ExpedicaoService() {

    }

    public Fornecedor getFornecedor() {
        return new Fornecedor();
    }

    public ProdutoExpedicao getProdutoExpedicao() {
        return new ProdutoExpedicao();
    }

    public PedidoExpedicao getPedidoExpedicao() {
        return new PedidoExpedicao();
    }
}
