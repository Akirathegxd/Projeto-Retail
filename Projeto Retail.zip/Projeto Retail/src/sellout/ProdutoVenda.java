package sellout;

import services.VendaService;

public class ProdutoVenda {
    private VendaService vendaService;

    public ProdutoVenda() {

    }

    public void cadastrarProdutos() {

    }

    public void realizarPagamento() {

    }
}
