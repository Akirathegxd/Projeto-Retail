package sellout;

import services.VendaService;

public class PedidoVenda {
    private VendaService vendaService;

    public PedidoVenda() {

    }

    public void consultarProdutoEstoque() {

    }

    public void cadastrarSolicitacaoPedido() {

    }
}
