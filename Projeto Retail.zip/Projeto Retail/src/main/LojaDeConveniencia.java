package main;

import services.ExpedicaoService;
import services.VendaService;

public class LojaDeConveniencia {
    private VendaService vendaService;
    private ExpedicaoService expedicaoService;

    public LojaDeConveniencia() {

    }

    public VendaService getVendaService() {
        return new VendaService();
    }

    public ExpedicaoService getExpedicaoService() {
        return new ExpedicaoService();
    }
}
