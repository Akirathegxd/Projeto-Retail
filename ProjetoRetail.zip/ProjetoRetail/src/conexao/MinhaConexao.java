package conexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.JOptionPane;

public class MinhaConexao {
    public static final String usuario = "postgres.acvdibssccnvsududjdq";
    public static final String senha = "Sicaj123@$123";
    public static final String url = "jdbc:postgresql://aws-0-sa-east-1.pooler.supabase.com:5432/postgres";
    public static Connection conn = null;

    public static Connection getConnection() {
        try {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(url, usuario, senha);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, ""+e, "", JOptionPane.WARNING_MESSAGE);
        }
        return conn;
    }
}
