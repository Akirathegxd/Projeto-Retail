package JFrameInterfaces;

import expedition.Fornecedor;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;

public class CadastroFornecedor extends JFrame {
    private final JTextField txtDescricao;
    private final JTextField txtCnpj;
    private final JTextField txtEmail;
    private final JTextField txtTelefone;
    private final JButton btnCadastrar;

    static class Funcionario {
        protected String descricao;
        private String cnpj;
        private String email;
        private String telefone;
        private int idFornecedor;

        public String getDescricao() {
            return descricao;
        }

        public void setDescricao(String descricao) {
            this.descricao = descricao;
        }

        public String getCnpj() {
            return cnpj;
        }

        public void setCnpj(String cnpj) {
            this.cnpj = cnpj;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public String getTelefone() {
            return telefone;
        }

        public void setTelefone(String telefone) {
            this.telefone = telefone;
        }

        public int getIdFornecedor() {
            return idFornecedor;
        }

        public void setIdFornecedor(int idFornecedor) {
            Random rand = new Random();
            this.idFornecedor = rand.nextInt(1000, 8000) + 1;
        }

    }

    public CadastroFornecedor() {
        super("Cadastro de Fornecedor");
        setLayout(new FlowLayout());

        // Cria os componentes da interface
        txtDescricao = new JTextField(20);
        txtCnpj = new JTextField(20);
        txtEmail = new JTextField(20);
        txtTelefone = new JTextField(20);
        btnCadastrar = new JButton("Cadastrar");

        // Adiciona os componentes ao frame
        add(new JLabel("Detalhes:"));
        add(txtDescricao);
        add(new JLabel("CNPJ:"));
        add(txtCnpj);
        add(new JLabel("Email:"));
        add(txtEmail);
        add(new JLabel("Telefone:"));
        add(txtTelefone);
        add(btnCadastrar);

        // comportamento do botão
        btnCadastrar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Fornecedor fornecedor = new Fornecedor();
                fornecedor.setDescricao(txtDescricao.getText());
                fornecedor.setCnpj(txtCnpj.getText());
                fornecedor.setEmail(txtEmail.getText());
                fornecedor.setTelefone(txtTelefone.getText());

                JOptionPane.showMessageDialog(null, "Fornecedor cadastrado com sucesso!");
            }
        });

        Toolkit t = Toolkit.getDefaultToolkit();
        Dimension dimensao = t.getScreenSize();

        int larg = dimensao.width;
        int alt = dimensao.height;

        double larg2 = 0.190336*larg;
        int larg3 = (int)larg2;

        double alt2 = 0.390625*alt;
        int alt3 = (int)alt2;

        setSize(larg3, alt3);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
        setResizable(false);
    }

    /* Para instanciar no main.Main:

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new CadastroFornecedor();
            }
        });
    }

    */
}