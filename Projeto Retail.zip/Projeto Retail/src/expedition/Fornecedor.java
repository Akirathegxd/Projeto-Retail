package expedition;

public class Fornecedor {
    private String email;
    private String cnpj;
    private String descricao;
    private String telefone;

    public Fornecedor() {

    }

    public void cadastrarFornecedor() {

    }

    public void consultarFornecedor() {

    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
}
