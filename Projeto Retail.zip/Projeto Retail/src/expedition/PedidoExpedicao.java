package expedition;

import services.ExpedicaoService;

public class PedidoExpedicao {
    private ExpedicaoService expedicaoService;

    public PedidoExpedicao() {

    }

    public void consultarSolicitacaoRecebida() {

    }

    public void realizarSolicitacaoPedidoFornecedor() {

    }

    private void confirmarRecebimentoPedido() {

    }

    private void cancelarPedido() {

    }

    public void consultarPedido() {

    }
}
