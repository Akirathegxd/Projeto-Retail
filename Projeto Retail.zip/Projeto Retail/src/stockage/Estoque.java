package stockage;

import expedition.ProdutoExpedicao;

public class Estoque {
    private ProdutoExpedicao produtoExpedicao;
    private String validade;
    private String marca;
    private String tipo;
    private int quantidade;
}
