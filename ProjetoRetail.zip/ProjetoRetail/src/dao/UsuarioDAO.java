package dao;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import conexao.MinhaConexao;

public class UsuarioDAO {
    Connection conn = MinhaConexao.getConnection();
    PreparedStatement preparedStatement;
    Statement statement;
    ResultSet resultSet;

    public int getMaxRow() {
        int row = 0;
        try {
            statement = conn.createStatement();
            resultSet = statement.executeQuery("SELECT");
            
        } catch (Exception e) {
            
        }
    }
}
