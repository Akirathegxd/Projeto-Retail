package expedition;

import services.ExpedicaoService;

public class ProdutoExpedicao {
    private ExpedicaoService expedicaoService;

    public void disponibilizarProdutosLoja() {

    }

    public void consultarProdutosEstoque() {

    }
}
